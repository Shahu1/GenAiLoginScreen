using System.Threading.Tasks;

namespace UserLogin.Interfaces
{
    public interface IUserRepository
    {
        Task<User> GetUserByUsernameAsync(string username);
    }
}